<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="utf-8">

   <link rel="stylesheet" type="text/css"
   href="http://fonts.googleapis.com/css?family=Advent+Pro%7CBangers%7CSlackey%7CSigmar+One%7CRighteous%7CUbuntu">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
   <title>Scrabble</title>
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="css/bootstrap-theme.min.css">
   <link rel="stylesheet" type="text/css" href="css/sweetalert.css">
   <link rel="stylesheet" href="css/scrabble_v2.css">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
   <link rel="shortcut icon" href="img/scrabble.ico" type="image/x-icon">
   <div id="player">
    <audio autoplay hidden>
     <source src="music.mp3" type="audio/mpeg">
                
    </audio>
</div>
</head>

<body>
  <div class="Login-credentials"><a href="logout.php"><button class="btn">Logout</button></a></div>
  <div class="header">

    <h3 class="logo">Scrabble Multiplayer Game</h3>
    <input type="checkbox" id="chk">
    <label for="chk" class="show-menu-btn">
      <i class="fas fa-ellipsis-h"></i>
    </label>

    <ul class="menu">
      <a href="index.php">Home</a>
      <a href="rules.html">Rules & Condition</a>
      <a href="contact-form.php">Contact</a>
      <a href="#">About Us</a>
      
      <label for="chk" class="hide-menu-btn">
        <i class="fas fa-times"></i>
      </label>
    </ul>
  </div>
  <!-- First row - the Scrabble game board -->
  <div class="row-fluid">

        <div class="d-flex justify-content-between">
          <div class="text-center">
          <div class="highlight_centered">
            
            Word: <span id="word">____</span>
            <div class="divider"></div>
            Score: <span id="score">0</span>
          </div>
          </div>
        </div>

        <div class="d-flex justify-content-between">
          <div class="text-center">
          <button onclick="submit_word()">Submit Word</button>
          <div class="divider"></div>
          <button onclick="reset_tiles();">Recall Tiles</button>
          <div class="divider"></div>
          <button class="button_spacing" onclick="confirm_reset();">Reset Board</button>
        </div></div>
        <div class="d-flex justify-content-between">
          <div id="messages"></div>
        </div>


    <div class="d-flex justify-content-between">
      <div class="center_text_images">
        <table id="scrabble_board">
          <!-- First Row -->
          <tr>
            <td class="triple_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_word">
            </td>
          </tr>

          <!-- Second Row -->
          <tr>
            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>
          </tr>

          <!-- Third Row -->
          <tr>
            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>
          </tr>

          <!-- 4th Row -->
          <tr>
            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>
          </tr>

          <!-- 5th Row -->
          <tr>
            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>
          </tr>

          <!-- 6th Row -->
          <tr>
            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>
          </tr>

          <!-- 7th Row -->
          <tr>
            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>
          </tr>

          <!-- 8th Row -->
          <tr>
            <td class="triple_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="star">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>
          </tr>

          <!-- 9th Row -->
          <tr>
            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>
          </tr>

          <!-- 10th Row -->
          <tr>
            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>
          </tr>

          <!-- 11th Row -->
          <tr>
            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>
          </tr>

          <!-- 12th Row -->
          <tr>
            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>
          </tr>

          <!-- 13th Row -->
          <tr>
            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>
          </tr>

          <!-- 14th Row -->
          <tr>
            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_word">
            </td>

            <td>
            </td>
          </tr>

          <!-- 15th Row -->
          <tr>
            <td class="triple_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_word">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="double_letter">
            </td>

            <td>
            </td>

            <td>
            </td>

            <td class="triple_word">
            </td>
          </tr>
        </table>
      </div>
      <br>
      <div class="d-flex justify-content-between">
        <div class="text-center">
        <img id="the_rack" src="img/scrabble/Scrabble_Rack_flat.resized.png" alt="scrabble rack">
        <div id="rack"></div>
        </div>   
      </div>
    </div>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js" type="text/javascript"></script>

  <!-- Custom Bootstrap with 14 grid! JavaScript file for it. -->
  <script src="js/scrabble/bootstrap.min.js" type="text/javascript"></script>

  <!-- jQuery UI -->
  <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js" type="text/javascript"></script>
  <script src="js/scrabble/jquery.ui.touch-punch.min.js" type="text/javascript"></script>

  <!-- Sweet Alerts! Awesome! -->
  <script src="js/scrabble/sweetalert.min.js" type="text/javascript"></script>

  <!-- JS Global Variables -->
  <script src="js/scrabble/variables.js" type="text/javascript"></script>

  <!-- Functions that the three buttons run are found here. "Submit", "Recall", "Reset" buttons. -->
  <script src="js/scrabble/buttons.js" type="text/javascript"></script>
  <script src="js/scrabble/util.js" type="text/javascript"></script>
  <script src="js/scrabble/score.js" type="text/javascript"></script>
  <script src="js/scrabble/draggable.js" type="text/javascript"></script>
  <script src="js/scrabble/droppable.js" type="text/javascript"></script>
  <script src="js/scrabble/scrabble_v2.js" type="text/javascript"></script>

</body>
</html>
