scrabble
========

A scrabble clone in pure html and javascript with a fancy ai 

Try it live on https://scrabble.77177.de/

Also with multiplayer option to play with other humans

Multiplayer live on https://scrabble.77177.de/multiplayer
