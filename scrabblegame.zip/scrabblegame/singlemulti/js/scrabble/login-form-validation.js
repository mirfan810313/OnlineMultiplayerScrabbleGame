$(document).ready(function(){
	$('span').hide();
$('#email').keyup(function(){
		var email=$('#email').val();
		if (isValidEmailAddress(email)) {
		$('.emailerror').hide();
			}else {
				$('.emailerror').show().html("Please type a valid Email");
			}
		});	



$('#password').keyup(function(){
		var pass=$('#password').val();
		if (pass.length<8 || pass.length>20) {
			$('.passerror').show().html("Your Password Must Contain At Least 8 Characters!");
			}else if(!pass.match(/[a-z]/) ) {
					$('.passerror').show().html("Your Password Must Contain At Least 1 Lowercase Letter!");
				}else if(!pass.match(/[A-Z]/) ) {
					$('.passerror').show().html("Your Password Must Contain At Least 1 Uppercase Letter!");
				}else if(!pass.match(/\d/) ) {
					$('.passerror').show().html("Your Password Must Contain At Least 1 Number!");
				}

			else {
				$('.passerror').hide();
			}
		});	

});


function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    return pattern.test(emailAddress);
}