<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="Login Credentials.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <style type="text/css">
    	.img-icon {
    		width: 10px;
    		height: 100px;
  			border: 1px solid #ddd;
  			border-radius: 4px;
  			padding: 5px;
  			
}
 .error {color: #FF0000;}
 textarea {
  width: 100%;
  padding: 10px 0;
  margin: 5px;
  border-left: 0;
  border-top:0;
  border-right: 0;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
    </style>
  </head>
  <body>
      
      

  <div class="header">

    <h2 class="logo">Scrabble Multiplayer Game</h2>
    <input type="checkbox" id="chk">
    <label for="chk" class="show-menu-btn">
      <i class="fas fa-ellipsis-h"></i>
    </label>

    <ul class="menu">
      <a href="index.php">Home</a>
      <a href="#">Rules & Condition</a>
      <a href="#">Contact</a>
      <a href="#">About Us</a>
      
      <label for="chk" class="hide-menu-btn">
        <i class="fas fa-times"></i>
      </label>
    </ul>
  </div>


<div class="content">
    <center>
    	
    	<div class="Form-box">
    	<div class="Icon-box">
    	<img class="img-icon" src="icon2.png"></div>

      <form id="contact" class="input-group" action=""  method="POST"  >

        <input type="text" class="input-feild" name="fname" placeholder="First Name" id="form-fname" required>
        <input type="text" class="input-feild" name="lname" placeholder="Last Name" id="form-lname" required>
        <input type="Email" class="input-feild" name="email" placeholder="Enter Email" id="email" id="form-email" required>
        
        <textarea placeholder="Type your message here&nbsp;*" rows="6" required></textarea>
        
        <input type="submit" class="submit-btn" name="submit" value="Submit" id="submit">
        

      </form>
      </div></center>

   
    </div>
  </body>
</html>
