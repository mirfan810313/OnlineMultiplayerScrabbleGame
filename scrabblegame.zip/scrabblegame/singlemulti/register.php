<?php
session_start();
$conn=mysqli_connect("localhost","root","","regist");

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['Uname'];
$email=$_POST['email'];
$password=md5($_POST['password']);

$query="INSERT INTO users(`id`,`first_name`,`last_name`,`u_name`,`email`,`password`)VALUES('','$fname','$lname','$uname','$email','$password')";

$run=mysqli_query($conn,$query);

if($run){
	$_SESSION['success']="successfully register";
	header('Location:Login-form.php');
}
else{
	echo "unsuccessfully register";
}
?>