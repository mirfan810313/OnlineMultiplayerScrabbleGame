<?php

class Player {
    public $id;
    public $language;
    public $name;
    public $gameId;
}