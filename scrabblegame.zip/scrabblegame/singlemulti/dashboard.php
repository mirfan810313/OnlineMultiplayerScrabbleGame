<?php include "auth.php"; ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <script>
      var bleep=new Audio();
      bleep.src="touch.mp3";
    </script>
  </head>
<body>
      <div class="Login-credentials"><a href="logout.php"><button class="btn">Logout</button></a></div>
      

  <div class="header">

    <h2 class="logo">Scrabble Multiplayer Game</h2>
    <input type="checkbox" id="chk">
    <label for="chk" class="show-menu-btn">
      <i class="fas fa-ellipsis-h"></i>
    </label>

    <ul class="menu">
      <a href="index.php">Home</a>
      <a href="rules.html">Rules & Condition</a>
      <a href="contact-form.php">Contact</a>
      <a href="#">About Us</a>
      
      <label for="chk" class="hide-menu-btn">
        <i class="fas fa-times"></i>
      </label>
    </ul>
  </div>


<div class="content" style="text-align: center;">
   
        <div class="start"><a href="self-practise.php" onmouseenter="bleep.play();"><button class="start-btn">Self Practise</button></a></div>
        <div class="start"><a href="index.html" onmouseenter="bleep.play();"><button class="start-btn">Play With Computer</button></a></div>
        <div class="start"><a href="multiplayer/index.php" onmouseenter="bleep.play();"><button class="start-btn">Play With MultiPlayer</button></a></div>
        <div class="start"><a href="rules.html" onmouseenter="bleep.play();"><button class="start-btn">Rules</button></a></div>
        <div class="start"><a href="logout.php" onmouseenter="bleep.play();"><button class="start-btn">Logout</button></a></div>
    

   
    </div>
  </body>
</html>