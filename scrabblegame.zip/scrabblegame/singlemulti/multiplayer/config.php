<?php
require_once ('connector/GameConnector.php');
require_once ('connector/LoungeConnector.php');
require_once ('connector/PlayerConnector.php');
require_once ('language/English.php');
require_once ('language/German.php');
require_once ('model/Game.php');
require_once ('model/Player.php');