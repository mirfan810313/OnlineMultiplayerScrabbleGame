<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
  </head>
  <body>
      <div class="Login-credentials"><a href="login-form.php"><button class="btn">Login</button></a><a href="register-form.php"><button class="btn">Register</button></a></div>
      
      

  <div class="header">

    <h2 class="logo">Scrabble Multiplayer Game</h2>
    <input type="checkbox" id="chk">
    <label for="chk" class="show-menu-btn">
      <i class="fas fa-ellipsis-h"></i>
    </label>

    <ul class="menu">
      <a href="index.php">Home</a>
      <a href="rules.html">Rules & Condition</a>
      <a href="contact-form.php">Contact</a>
      <a href="#">About Us</a>
      
      <label for="chk" class="hide-menu-btn">
        <i class="fas fa-times"></i>
      </label>
    </ul>
  </div>


<div class="content">
    <center>
  
    </center>

   
    </div>
  </body>
</html>
