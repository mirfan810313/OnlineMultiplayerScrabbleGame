<?php include "../../auth.php"; ?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="description" content=""/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
 <link rel="stylesheet" href="css/scrabble_v2.css">
  <script type="text/javascript" src="game.js"></script>
  <script type="text/javascript" src="translation.js"></script>
<title>Scrabble</title>
</head>
<body>
<div class="Login-credentials" style="text-align: right;"><a href="../../logout.php"><button class="btn">Logout</button></a></div>
<div style="text-align: center;">
 <div class="score_container">
      <div style="font-size:20px" class="player_name"><script>document.write(i18n("You"))</script>: </div><div class="player_name" id="player_1_points">0</div>
     
      <div style="font-size:20px" class="player_name" id="opponent_name"><script>document.write(i18n("KI"))</script>: </div><div class="player_name" id="player_2_points">0</div><br>
      <div style="font-size:20px" class="letters_left"><script>document.write(i18n("Other letters"))</script>: <span id="letters_left"></span>
      </div>
    </div>
</div>

<!-- <div class="wrapper"> -->

  <div class="game">
    <table id="board" >
      <tr><td id="s1_1" class="tw" title="Triple word value"></td><td id="s1_2"></td><td id="s1_3"></td><td id="s1_4" class="dl" title="Double letter value"></td><td id="s1_5"></td><td id="s1_6"></td><td id="s1_7"></td><td id="s1_8" class="tw" title="Triple word value"></td><td id="s1_9"></td><td id="s1_10"></td><td id="s1_11"></td><td id="s1_12" class="dl" title="Double letter value"></td><td id="s1_13"></td><td id="s1_14"></td><td id="s1_15" class="tw" title="Triple word value"></td></tr>
      <tr><td id="s2_1"></td><td id="s2_2" class="dw" title="Double word value"></td><td id="s2_3"></td><td id="s2_4"></td><td id="s2_5"></td><td id="s2_6" class="tl" title="Triple letter value"></td><td id="s2_7"></td><td id="s2_8"></td><td id="s2_9"></td><td id="s2_10" class="tl" title="Triple letter value"></td><td id="s2_11"></td><td id="s2_12"></td><td id="s2_13"></td><td id="s2_14" class="dw" title="Double word value"></td><td id="s2_15"></td></tr>
      <tr><td id="s3_1"></td><td id="s3_2"></td><td id="s3_3" class="dw" title="Double word value"></td><td id="s3_4"></td><td id="s3_5"></td><td id="s3_6"></td><td id="s3_7" class="dl" title="Double letter value"></td><td id="s3_8"></td><td id="s3_9" class="dl" title="Double letter value"></td><td id="s3_10"></td><td id="s3_11"></td><td id="s3_12"></td><td id="s3_13" class="dw" title="Double word value"></td><td id="s3_14"></td><td id="s3_15"></td></tr>
      <tr><td id="s4_1" class="dl" title="Double letter value"></td><td id="s4_2"></td><td id="s4_3"></td><td id="s4_4" class="dw" title="Double word value"></td><td id="s4_5"></td><td id="s4_6"></td><td id="s4_7"></td><td id="s4_8" class="dl" title="Double letter value"></td><td id="s4_9"></td><td id="s4_10"></td><td id="s4_11"></td><td id="s4_12" class="dw" title="Double word value"></td><td id="s4_13"></td><td id="s4_14"></td><td id="s4_15" class="dl" title="Double letter value"></td></tr>
      <tr><td id="s5_1"></td><td id="s5_2"></td><td id="s5_3"></td><td id="s5_4"></td><td id="s5_5" class="dw" title="Double word value"></td><td id="s5_6"></td><td id="s5_7"></td><td id="s5_8"></td><td id="s5_9"></td><td id="s5_10"></td><td id="s5_11" class="dw" title="Double word value"></td><td id="s5_12"></td><td id="s5_13"></td><td id="s5_14"></td><td id="s5_15"></td></tr>
      <tr><td id="s6_1"></td><td id="s6_2" class="tl" title="Triple letter value"></td><td id="s6_3"></td><td id="s6_4"></td><td id="s6_5"></td><td id="s6_6" class="tl" title="Triple letter value"></td><td id="s6_7"></td><td id="s6_8"></td><td id="s6_9"></td><td id="s6_10" class="tl" title="Triple letter value"></td><td id="s6_11"></td><td id="s6_12"></td><td id="s6_13"></td><td id="s6_14" class="tl" title="Triple letter value"></td><td id="s6_15"></td></tr>
      <tr><td id="s7_1"></td><td id="s7_2"></td><td id="s7_3" class="dl" title="Double letter value"></td><td id="s7_4"></td><td id="s7_5"><td id="s7_6"></td><td id="s7_7" class="dl" title="Double letter value"></td><td id="s7_8"></td><td id="s7_9" class="dl" title="Double letter value"></td><td id="s7_10"></td><td id="s7_11"></td><td id="s7_12"></td><td id="s7_13" class="dl" title="Double letter value"><td id="s7_14"></td><td id="s7_15"></td></tr>
      <tr><td id="s8_1" class="tw" title="Triple word value"></td><td id="s8_2"></td><td id="s8_3"></td><td id="s8_4" class="dl" title="Double letter value"></td><td id="s8_5"></td><td id="s8_6"></td><td id="s8_7"></td><td id="s8_8" class="start dw"></td><td id="s8_9"><td id="s8_10"></td><td id="s8_11"></td><td id="s8_12" class="dl" title="Double letter value"></td><td id="s8_13"></td><td id="s8_14"></td><td id="s8_15" class="tw" title="Triple word value"></td></tr>
      <tr><td id="s9_1"></td><td id="s9_2"></td><td id="s9_3" class="dl" title="Double letter value"></td><td id="s9_4"></td><td id="s9_5"></td><td id="s9_6"></td><td id="s9_7" class="dl" title="Double letter value"></td><td id="s9_8"></td><td id="s9_9" class="dl" title="Double letter value"></td><td id="s9_10"></td><td id="s9_11"></td><td id="s9_12"></td><td id="s9_13" class="dl" title="Double letter value"></td><td id="s9_14"></td><td id="s9_15"></td></tr>
      <tr><td id="s10_1"></td><td id="s10_2" class="tl" title="Triple letter value"></td><td id="s10_3"></td><td id="s10_4"></td><td id="s10_5"></td><td id="s10_6" class="tl" title="Triple letter value"></td><td id="s10_7"></td><td id="s10_8"></td><td id="s10_9"></td><td id="s10_10" class="tl" title="Triple letter value"></td><td id="s10_11"></td><td id="s10_12"></td><td id="s10_13"></td><td id="s10_14" class="tl" title="Triple letter value"></td><td id="s10_15"></td></tr>
      <tr><td id="s11_1"></td><td id="s11_2"></td><td id="s11_3"></td><td id="s11_4"></td><td id="s11_5" class="dw" title="Double word value"></td><td id="s11_6"></td><td id="s11_7"></td><td id="s11_8"></td><td id="s11_9"></td><td id="s11_10"></td><td id="s11_11" class="dw" title="Double word value"></td><td id="s11_12"></td><td id="s11_13"></td><td id="s11_14"></td><td id="s11_15"></td></tr>
      <tr><td id="s12_1" class="dl" title="Double letter value"></td><td id="s12_2"></td><td id="s12_3"></td><td id="s12_4" class="dw" title="Double word value"><td id="s12_5"><td id="s12_6"><td id="s12_7"><td id="s12_8" class="dl" title="Double letter value"><td id="s12_9"></td><td id="s12_10"></td><td id="s12_11"></td><td id="s12_12" class="dw" title="Double word value"></td><td id="s12_13"></td><td id="s12_14"></td><td id="s12_15" class="dl" title="Double letter value"></td></tr>
      <tr><td id="s13_1"></td><td id="s13_2"></td><td id="s13_3" class="dw" title="Double word value"></td><td id="s13_4"></td><td id="s13_5"></td><td id="s13_6"></td><td id="s13_7" class="dl" title="Double letter value"></td><td id="s13_8"></td><td id="s13_9" class="dl" title="Double letter value"></td><td id="s13_10"></td><td id="s13_11"></td><td id="s13_12"></td><td id="s13_13" class="dw" title="Double word value"></td><td id="s13_14"></td><td id="s13_15"></td></tr>
      <tr><td id="s14_1"></td><td id="s14_2" class="dw" title="Double word value"></td><td id="s14_3"></td><td id="s14_4"></td><td id="s14_5"></td><td id="s14_6" class="tl" title="Triple letter value"></td><td id="s14_7"></td><td id="s14_8"></td><td id="s14_9"></td><td id="s14_10" class="tl" title="Triple letter value"></td><td id="s14_11"></td><td id="s14_12"></td><td id="s14_13"></td><td id="s14_14" class="dw" title="Double word value"></td><td id="s14_15"></td></tr>
      <tr><td id="s15_1" class="tw" title="Triple word value"></td><td id="s15_2"></td><td id="s15_3"></td><td id="s15_4" class="dl" title="Double letter value"></td><td id="s15_5"></td><td id="s15_6"></td><td id="s15_7"></td><td id="s15_8" class="tw" title="Triple word value"></td><td id="s15_9"></td><td id="s15_10"></td><td id="s15_11"></td><td id="s15_12" class="dl" title="Double letter value"></td><td id="s15_13"></td><td id="s15_14"></td><td id="s15_15" class="tw" title="Triple word value"></td></tr>
    </table>
    </div>
    
   
    <div id="your_letters"><script>document.write(i18n("Your letters:"))</script></div>
    <div class="rack">
    <div id="player_1_letters"></div>
    <div class="btn">
    <button class="button" title="Active on a valid move" onclick="onFinishMoveClick()" id="move"><script>document.write(i18n("Play"))</script></button><br>
    <button class="button" onclick="onSelectSwapTilesClicked()" id="pass"><script>document.write(i18n("Swap"))</script></button>
    </div>
<div id="input_container"></div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js" type="text/javascript"></script>

  <!-- Custom Bootstrap with 14 grid! JavaScript file for it. -->
  <script src="js/scrabble/bootstrap.min.js" type="text/javascript"></script>

  <!-- jQuery UI -->
  <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js" type="text/javascript"></script>
  <script src="js/scrabble/jquery.ui.touch-punch.min.js" type="text/javascript"></script>

  <!-- Sweet Alerts! Awesome! -->
  <script src="js/scrabble/sweetalert.min.js" type="text/javascript"></script>

  <script src="js/scrabble/scrabble_v2.js" type="text/javascript"></script>

</body>
</html>
