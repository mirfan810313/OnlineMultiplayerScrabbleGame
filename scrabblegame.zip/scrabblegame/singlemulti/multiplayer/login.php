<?php
session_start();
$conn=mysqli_connect("localhost","root","","regist");

if(isset($_POST['email'])){
	$email=$_POST['email'];
	$password=md5($_POST['password']);

	$query="Select * from users where email='$email' AND password='$password'";
	$run=mysqli_query($conn,$query);
	$count=mysqli_num_rows($run);
	if($count==1){
		$session_id = session_id();
		$_SESSION['auth'] = $session_id;
		header('Location:index.php');
		echo "login success";
	}else{
		$_SESSION['error']="Wrong Email or Password";
		header('Location:../login-form.php');
	}
}

?>