$(document).ready(function(){
	$('span').hide();
	$('#form-fname').keyup(function(){
		var fname=$(this).val();
		if (!fname.match('^[a-zA-Z]{3,20}$')) {
		 $('.fnerror').show().html("First Name Should be between 3 to 20 character's");
			}else{
				$('.fnerror').hide();
			}
		});	

	

	$('#form-lname').keyup(function(){
		var lname=$(this).val();
		if (!lname.match('^[a-zA-Z]{3,20}$')) {
		 $('.lnerror').show().html("Last Name Should be between 3 to 20 character's");
			}else{
				$('.lnerror').hide();
			}
		});	
		

	$('#form-username').keyup(function(){
		var uname=$(this).val();
		if (!uname.match('^[a-zA-Z0-9]{5,20}$')) {
		 $('.unerror').show().html("Userame Should be between 5 to 20 character's");
			}else if (!uname.match(/\d/)) {
		 $('.unerror').show().html("Userame Must Contain At Least 1 Number!");
			}
			else{
				$('.unerror').hide();
			}
		});	
		

	$('#email').keyup(function(){
		var email=$('#email').val();
		if (isValidEmailAddress(email)) {
		$('.emailerror').hide();
			}else {
				$('.emailerror').show().html("Please type a valid Email");
			}
		});	

	$('#password').keyup(function(){
		var pass=$('#password').val();
		if (pass.length<8 || pass.length>20) {
			$('.passerror').show().html("Your Password Must Contain At Least 8 Characters!");
			}else if(!pass.match(/[a-z]/) ) {
					$('.passerror').show().html("Your Password Must Contain At Least 1 Lowercase Letter!");
				}else if(!pass.match(/[A-Z]/) ) {
					$('.passerror').show().html("Your Password Must Contain At Least 1 Uppercase Letter!");
				}else if(!pass.match(/\d/) ) {
					$('.passerror').show().html("Your Password Must Contain At Least 1 Number!");
				}

			else {
				$('.passerror').hide();
			}
		});	

	$('#confirmpassword').keyup(function(){
		var pass=$('#password').val();
		var conpass=$('#confirmpassword').val();
		if(conpass!=pass){
			$('.confirmpasserror').show().html("Your Password must be match");
		}else{
			$('.confirmpasserror').hide();
		}

	});

	

	});



function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    return pattern.test(emailAddress);
}
