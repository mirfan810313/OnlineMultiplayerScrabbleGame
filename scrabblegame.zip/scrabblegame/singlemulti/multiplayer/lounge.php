<?php include "auth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="description" content="Join Multiplayer Scrabble game"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <title>Scrabble Multiplayer</title>
    <script>
      function getUrlParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
          results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
      }

      setTimeout(
        function() {
          var playerId = getUrlParameterByName('playerId');
          location = '1_matchmaker.php?playerId=' + playerId;
        },
        2000
      );
    </script>
</head>
<body>

<div id="waitingLayer" style="text-align: center; margin-top: 100px">
    Waiting for other player to join.<br/>
    <a href="../dashboard.php" target="_blank">Go Back</a>
</div>

</body>
</html>
