var pieces = [];
var game_board = [];
var complete_words = [];
// This gets configured by load_scrabble_pieces()
var game_tiles = [
  {"id": "piece0", "letter": "A"},
  {"id": "piece1", "letter": "B"},
  {"id": "piece2", "letter": "C"},
  {"id": "piece3", "letter": "D"},
  {"id": "piece4", "letter": "E"},
  {"id": "piece5", "letter": "F"},
  {"id": "piece6", "letter": "G"}
];

// Boolean for reading left to right or top to bottom
var left_right = false;

// For detecting multiple words played
var number_of_words = 0;
var startPos;

var dict = {};
$.get("files/dictionary.txt", function(txt) {
    var words = txt.split( "\n" );
    for ( var i = 0; i < words.length; i++ ) {
        dict[ words[i] ] = true;
    }
});


var word_score = 0;
var first_letter = "";
var used_letters = 0;
