<?php include "auth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="description" content="An open source implementation of the word puzzle scrabble in pure html, js and css."/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../styles.css">
    <title>Scrabble Multiplayer</title>
    <script>
      function showWaiting() {
        var form = document.getElementById("registerForm");
        if (!form.checkValidity || form.checkValidity()) {
          document.getElementById("registerForm").style.visibility = 'hidden';
        }
      }
    </script>




   
</head>
<body>
<style>
div {
  
  background-color:#ffffff;
}
</style>
<div style="text-align: center; margin-top: 300px;">
<h1>Join a team</h1>
<form METHOD="post" action="0_register.php" id="registerForm">
    <label>
        Enter your Nick Name:<br> <input name="playerName" type="text" required="required" pattern="[A-Za-z0-9]{3,20}">
    </label>
    
    <button type="submit" class="btn btn-success"onclick="showWaiting()">Join</button>
</form>
</div>
</body>
</html>
